@echo off
docker run --rm -v radicle-home:/root/.radicle -v "%cd%:/proofcash" -e RAD_PASSPHRASE=ProofCashC#42@5% proofcash-radicle rad %*
