param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$RadArgs
)

docker run --rm -v "radicle-home:/root/.radicle" -v "${PWD}:/proofcash" -e RAD_PASSPHRASE="ProofCashC#42@5%" proofcash-radicle rad @RadArgs
